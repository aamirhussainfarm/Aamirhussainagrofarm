Aamir Hussain Agro & Livestock Farm website
===============================================
Main file: index.html

Publish options:
1. GitHub Pages: create a public repository named aamirhussainagrofarm.github.io and upload index.html.
2. Cloudflare Pages: upload/connect this folder and deploy.

After publishing, use the final website address in:
- Facebook Page website field
- Instagram bio
- WhatsApp Business website field
- Google Business Profile website field

Important:
- Replace the placeholder hero photo URL with your own farm photo later if desired.
- Google Search indexing is not immediate; submit the published site in Google Search Console.
